function cart(id,name,price)
{
document.forms["frmcart"].id.value=id;
document.forms["frmcart"].hidden_name.value=name;
document.forms["frmcart"].hidden_price.value=price;
document.forms["frmcart"].command.value='add';
document.forms["frmcart"].submit();
}
function update(id,quantity)
{
document.forms["frmcart"].id.value=id;
document.forms["frmcart"].quantity.value=quantity;
document.forms["frmcart"].command.value='update';
document.forms["frmcart"].submit();
}
function del(id)
{
document.forms["frmcart"].id.value=id;
document.forms["frmcart"].command.value='delete';
document.forms["frmcart"].submit();
}
function clearall()
{
document.forms["frmcart"].command.value='clear';
document.forms["frmcart"].submit();
}