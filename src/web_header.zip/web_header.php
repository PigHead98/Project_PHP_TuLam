<header>
	<div class="header top">
		<ul>
		<li id="systemshop"><a href="#"> <i class="fa fa-location-arrow" aria-hidden="true"></i><span class="txt-b">Hệ Thống Cửa Hàng</span></a></li>
		<li><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i><span class="txt-b">Mua Sắm</span></a></li>
		<li><a href="#"> <i class="fa fa-location-arrow" aria-hidden="true"></i><span class="txt-b">Chăm sóc</span></a></li>
		<li><a href="#"><i class="fa fa-location-arrow" aria-hidden="true"></i><span class="txt-b">Dịch Vụ</span></a></li>
		<li id="rescallsuport"><a href="#"><i class="fa fa-phone" aria-hidden="true"></i><span class="txt-b">012356469</span></a></li>
		<li id="ressearch"><a href="#"><i class="fa fa-search" aria-hidden="true"></i></a></li>
		</ul>
	</div>
	<div class="header bottom">
		<ul class="logo w25">
		<li><a href="<?=$root_dir?>index.php"><img src="<?=$root_dir?>img/logo.jpg" alt="logo"></a>
		</li>
		</ul>
		<ul class="search w50">
			<li id="box-social">
			<a id="callsuport"class="txt-b">Bạn cần giúp đỡ:<span class="main-color">01634217575</span></a>
			<div id="group-social">
			<a class="f-right"> <i class="fa fa-facebook-square" aria-hidden="true"></i></a>
			<a class="f-right"> <i class="fa fa-twitter" aria-hidden="true"></i></a>
			<a class="f-right"> <i class="fa fa-google-plus-square" aria-hidden="true"></i></a>
			<a class="f-right"> <i class="fa fa-instagram" aria-hidden="true"></i></a>
			</div>
			</li>
			<li id="box-search">
				<form name="frmseach">
				<input type="text" name="fname" placeholder="Bạn đang cần mua sản phẩm gì??"/>
				<select name="sltsearch" >
					<option value="">1</option>
					<option value="">2</option>
					<option value="">3</option>
				</select>
				<button name="btnseach"><i class="fa fa-search" aria-hidden="true"></i></button>
				</form>
			</li>
		</ul>
		<ul class="card w25">
		<li id="dcma"><a href="#"><img src="<?=$root_dir?>img/dmca_logo.png" alt="logo"></a>
		</li>
		<li id="card">
		
		<a href="#" data-toggle="modal" data-target="#modalshoping">
		
		<div class="cart-icon w50"><i class="fa fa-cart-arrow-down main-color " aria-hidden="true"></i></div>
		<div class="f-right w50 ">
		<span id="cart-text" class="txt-b ">Giỏ hàng<?=$shopping->count_item_shopping_cart()?></span>
		<span id="cart-total"><b><?=number_format($shopping->total_after_discount_shopping_cart())?><u>đ</u></b></span>
		</div>
		
		</a>
		</li><?=$shopping->list_item_shopping_cart('modalshoping')?>
		</ul>
		</div>
	
	</header>